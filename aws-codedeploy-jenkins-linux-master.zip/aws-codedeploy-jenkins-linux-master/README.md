# aws-codedeploy-jenkins-linux
This is a simple web app that can be deployed with Jenkins and AWS code services
